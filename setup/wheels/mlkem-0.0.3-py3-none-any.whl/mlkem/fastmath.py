# Pure Python fallback for fastmath
from mlkem.auxiliary.general import byte_decode, byte_encode

def byte_encode_matrix(matrix, d):
    return b''.join(byte_encode(d, p) for p in matrix)

def byte_decode_matrix(b, d, entries):
    chunk_len = 32 * d
    return [byte_decode(d, b[i * chunk_len : (i + 1) * chunk_len]) for i in range(entries)]
